
#include <sys/types.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#ifdef _BUILD_WITH_APPLE_MACOS_
#include <sys/sys_domain.h>
#include <sys/kern_control.h>
#include <net/if_utun.h>
#endif
#include <errno.h>
#include <stdio.h>
#include <string.h>
#include <syslog.h>
#include <unistd.h>
#include <stdlib.h>
#include "edge.h"
#include "n2nOntun_arp.h"
#include "n2nOntun.h"

//预设mac

static unsigned char deviceMac[DEVICE_MAC_LEN];

//libn2n中的调用函数
void send_register_super (n2n_edge_t *eee);
void send_query_peer (n2n_edge_t *eee, const n2n_mac_t dst_mac);
int supernode_connect (n2n_edge_t *eee);
int supernode_disconnect (n2n_edge_t *eee);
int fetch_and_eventually_process_data (n2n_edge_t *eee, SOCKET sock,
                                       uint8_t *pktbuf, uint16_t *expected, uint16_t *position,
                                       time_t now);
int resolve_check (n2n_resolve_parameter_t *param, uint8_t resolution_request, time_t now);
int edge_init_routes (n2n_edge_t *eee, n2n_route_t *routes, uint16_t num_routes);
static void processRoute(const char* routestr);
static void freeRoute();
//edge运行
static int keep_on_running=0;
static struct rcn2n_route* rcn2nroute = NULL;
static int    rcn2n_routesize = 0;
static TunCb* tuncb = NULL;
static void on_sn_registration_updated(n2n_edge_t *eee, time_t now, const n2n_sock_t *sn) {
}

static n2n_verdict on_packet_from_peer(n2n_edge_t *eee, const n2n_sock_t *peer,
                                       uint8_t *payload, uint16_t *payload_size) {
    if ( ((RCN2NARP*)payload)->ethhdr.type == htons(UIP_ETHTYPE_ARP)) {
        int dl = rcn2n_arpin_request(payload,*payload_size);
        if ( dl > 0) {
            edge_send_packet2net(eee, payload, dl);
        }
        return N2N_DROP;
    }
    return (N2N_ACCEPT);
}

/* *************************************************** */

static n2n_verdict on_packet_from_tap(n2n_edge_t *eee, uint8_t *payload,
                                      uint16_t *payload_size) {
    LocalIpMaskMac *lomm = (LocalIpMaskMac*)edge_get_userdata(eee);
    RCN2Nipv4* p = (RCN2Nipv4*)payload;
    //这里得到的是带空数据二层头的三层包
    unsigned char* destmac = findMacFormIpv4(p->destipaddr);
    unsigned int gateway = 0;
    if(destmac == NULL ) {
        //未找到目的mac，查看目的ip是否存在用于路由表中
        for (int i = 0; i < rcn2n_routesize; i++) {
            if (rcn2nroute[i].ipaddr == (p->destipaddr & rcn2nroute[i].ipmask)) {
                destmac = findMacFormIpv4(rcn2nroute[i].gateway);
                gateway = rcn2nroute[i].gateway;
                struct in_addr fip ,gip;
                fip.s_addr = p->destipaddr;
                gip.s_addr = gateway;
                break;
            }
        }
    }

    if ( destmac){
        memcpy(p->ethhdr.dest,destmac,6);
        memcpy(p->ethhdr.src,lomm->hostmac,6);
        p->ethhdr.type = htons(UIP_ETHTYPE_IP);
        return (N2N_ACCEPT);
    }

    if ( gateway != 0 ){
        //需要请求网关ip
        struct in_addr fip ,gip;
        fip.s_addr = p->destipaddr;
        gip.s_addr = gateway;
        traceEvent(TRACE_WARNING, "unfind route ip %s sendarp request %s ", inet_ntoa(fip), inet_ntoa(gip) );
        p->destipaddr = gateway;
    }

    //未找到目的ip的mac,发送arp请求
    int outlen = rcn2n_arpin_out(payload,*payload_size < sizeof(RCN2NARP) ? sizeof(RCN2NARP) : *payload_size);
    *payload_size = outlen;
    return N2N_ACCEPT;
}

void on_main_loop_period(n2n_edge_t *eee, time_t now) {
    rcn2n_timer_arp(now);
}

void stopedge(){
    keep_on_running=0;
}

int edgeStatus(){
    return keep_on_running;
}

/** Entry point to program from kernel. */
int _n2nmain (char* community_name,char* pk,char* publidIpport,const char* routeStr,TunCb* cb,unsigned char mac[DEVICE_MAC_LEN]) {
    memcpy(deviceMac,mac,DEVICE_MAC_LEN);
    tuncb = (TunCb*)malloc(sizeof(TunCb));
    memset(tuncb,0,sizeof(TunCb));
    if ( cb != NULL){
        memcpy(tuncb,cb,sizeof(TunCb));
    }
    if ( routeStr != NULL ) {
        processRoute(routeStr);
    }
    int rc;
    tuntap_dev tuntap;            /* a tuntap device */
    n2n_edge_t *eee;              /* single instance for this program */
    n2n_edge_conf_t conf;         /* generic N2N edge config */
    n2n_tuntap_priv_config_t ec;  /* config used for standalone program execution */
    uint8_t runlevel = 0;         /* bootstrap: runlevel */
    uint8_t seek_answer = 1;      /*            expecting answer from supernode */
    time_t now, last_action = 0;  /*            timeout */
    macstr_t mac_buf;             /*            output mac address */
    fd_set socket_mask;           /*            for supernode answer */
    struct timeval wait_time;     /*            timeout for sn answer */
    peer_info_t *scan, *scan_tmp; /*            supernode iteration */
    uint16_t expected = sizeof(uint16_t);
    uint16_t position = 0;
    uint8_t  pktbuf[N2N_SN_PKTBUF_SIZE + sizeof(uint16_t)]; /* buffer + prepended buffer length in case of tcp */
    LocalIpMaskMac lomm = {0};

#ifndef WIN32
    struct passwd *pw = NULL;
#endif

    /* Defaults */
    edge_init_conf_defaults(&conf);


    strcpy((char*)conf.community_name,community_name);
    if(edge_conf_add_supernode(&conf, publidIpport) != 0) {
        traceEvent(TRACE_WARNING, "failed to add supernode '%s'", publidIpport);
    }
    conf.encrypt_key = pk;
    conf.transop_id = N2N_TRANSFORM_ID_AES;


    memset(&ec, 0, sizeof(ec));
    ec.mtu = DEFAULT_MTU;
    ec.daemon = 1;        /* By default run in daemon mode. */

#ifndef WIN32
    if(((pw = getpwnam("n2n")) != NULL) ||
       ((pw = getpwnam("nobody")) != NULL)) {
        ec.userid = pw->pw_uid;
        ec.groupid = pw->pw_gid;
    }
#endif

    snprintf(ec.tuntap_dev_name, sizeof(ec.tuntap_dev_name), N2N_EDGE_DEFAULT_DEV_NAME);

    snprintf(ec.netmask, sizeof(ec.netmask), N2N_EDGE_DEFAULT_NETMASK);

    // --- additional crypto setup; REVISIT: move to edge_init()?
    // payload
    if(conf.transop_id == N2N_TRANSFORM_ID_NULL) {
        if(conf.encrypt_key) {
            // make sure that AES is default cipher if key only (and no cipher) is specified
            traceEvent(TRACE_WARNING, "switching to AES as key was provided");
            conf.transop_id = N2N_TRANSFORM_ID_AES;
        }
    }
    // user auth
    if(conf.shared_secret /* containing private key only so far*/) {
        // if user-password auth and no federation public key provided, use default
        if(!conf.federation_public_key) {
            conf.federation_public_key = calloc(1, sizeof(n2n_private_public_key_t));
            if(conf.federation_public_key) {
                traceEvent(TRACE_WARNING, "using default federation public key; FOR TESTING ONLY, usage of a custom federation name and key (-P) is highly recommended!");
                generate_private_key(*(conf.federation_public_key), &FEDERATION_NAME[1]);
                generate_public_key(*(conf.federation_public_key), *(conf.federation_public_key));
            }
        }
        // calculate public key and shared secret
        if(conf.federation_public_key) {
            traceEvent(TRACE_NORMAL, "using username and password for edge authentication");
            bind_private_key_to_username(*(conf.shared_secret), (char *)conf.dev_desc);
            conf.public_key = calloc(1, sizeof(n2n_private_public_key_t));
            if(conf.public_key)
                generate_public_key(*conf.public_key, *(conf.shared_secret));
            generate_shared_secret(*(conf.shared_secret), *(conf.shared_secret), *(conf.federation_public_key));
            // prepare (first 128 bit) for use as key
            conf.shared_secret_ctx = (he_context_t*)calloc(1, sizeof(speck_context_t));
            speck_init((speck_context_t**)&(conf.shared_secret_ctx), *(conf.shared_secret), 128);
        }
        // force header encryption
        if(conf.header_encryption != HEADER_ENCRYPTION_ENABLED) {
            traceEvent(TRACE_NORMAL, "enabling header encryption for edge authentication");
            conf.header_encryption = HEADER_ENCRYPTION_ENABLED;
        }
    }

    traceEvent(TRACE_NORMAL, "using compression: %s.", compression_str(conf.compression));
    traceEvent(TRACE_NORMAL, "using %s cipher.", transop_str(conf.transop_id));

    /* Random seed */
    n2n_srand (n2n_seed());

    if(conf.encrypt_key && !strcmp((char*)conf.community_name, conf.encrypt_key))
        traceEvent(TRACE_WARNING, "community and encryption key must differ, otherwise security will be compromised");

    if((eee = edge_init(&conf, &rc)) == NULL) {
        traceEvent(TRACE_ERROR, "failed in edge_init");
        keep_on_running=0;
        return 0;
    }

    memcpy(&(eee->tuntap_priv_conf), &ec, sizeof(ec));

    if((0 == strcmp("static", eee->tuntap_priv_conf.ip_mode)) ||
         ((eee->tuntap_priv_conf.ip_mode[0] == '\0') && (eee->tuntap_priv_conf.ip_addr[0] != '\0'))) {
        traceEvent(TRACE_NORMAL, "use manually set IP address");
        eee->conf.tuntap_ip_mode = TUNTAP_IP_MODE_STATIC;
    } else if(0 == strcmp("dhcp", eee->tuntap_priv_conf.ip_mode)) {
        traceEvent(TRACE_NORMAL, "obtain IP from other edge DHCP services");
        eee->conf.tuntap_ip_mode = TUNTAP_IP_MODE_DHCP;
    } else {
        traceEvent(TRACE_NORMAL, "automatically assign IP address by supernode");
        eee->conf.tuntap_ip_mode = TUNTAP_IP_MODE_SN_ASSIGN;
    }

    // mini main loop for bootstrap, not using main loop code because some of its mechanisms do not fit in here
    // for the sake of quickly establishing connection. REVISIT when a more elegant way to re-use main loop code
    // is found

    // find at least one supernode alive to faster establish connection
    // exceptions:
    if((HASH_COUNT(eee->conf.supernodes) <= 1) || (eee->conf.connect_tcp) || (eee->conf.shared_secret)) {
        // skip the initial supernode ping
        traceEvent(TRACE_DEBUG, "skip PING to supernode");
        runlevel = 2;
    }

    eee->last_sup = 0; /* if it wasn't zero yet */
    eee->curr_sn = eee->conf.supernodes;
    supernode_connect(eee);
    while(runlevel < 5) {

        now = time(NULL);

        // we do not use switch-case because we also check for 'greater than'

        if(runlevel == 0) { /* PING to all known supernodes */
            last_action = now;
            eee->sn_pong = 0;
            // (re-)initialize the number of max concurrent pings (decreases by calling send_query_peer)
            eee->conf.number_max_sn_pings = NUMBER_SN_PINGS_INITIAL;
            send_query_peer(eee, null_mac);
            traceEvent(TRACE_NORMAL, "send PING to supernodes");
            runlevel++;
        }

        if(runlevel == 1) { /* PING has been sent to all known supernodes */
            if(eee->sn_pong) {
                // first answer
                eee->sn_pong = 0;
                sn_selection_sort(&(eee->conf.supernodes));
                eee->curr_sn = eee->conf.supernodes;
                supernode_connect(eee);
                traceEvent(TRACE_NORMAL, "received first PONG from supernode [%s]", eee->curr_sn->ip_addr);
                runlevel++;
            } else if(last_action <= (now - BOOTSTRAP_TIMEOUT)) {
                // timeout
                runlevel--;
                // skip waiting for answer to direcly go to send PING again
                seek_answer = 0;
                traceEvent(TRACE_DEBUG, "PONG timeout");
            }
        }

        // by the way, have every later PONG cause the remaining (!) list to be sorted because the entries
        // before have already been tried; as opposed to initial PONG, do not change curr_sn
        if(runlevel > 1) {
            if(eee->sn_pong) {
                eee->sn_pong = 0;
                if(eee->curr_sn->hh.next) {
                    sn_selection_sort((peer_info_t**)&(eee->curr_sn->hh.next));
                    traceEvent(TRACE_DEBUG, "received additional PONG from supernode");
                    // here, it is hard to detemine from which one, so no details to output
                }
            }
        }

        if(runlevel == 2) { /* send REGISTER_SUPER to get auto ip address from a supernode */
            if(eee->conf.tuntap_ip_mode == TUNTAP_IP_MODE_SN_ASSIGN) {
                last_action = now;
                eee->sn_wait = 1;
                send_register_super(eee);
                runlevel++;
                traceEvent(TRACE_NORMAL, "send REGISTER_SUPER to supernode [%s] asking for IP address",
                                         eee->curr_sn->ip_addr);
            } else {
                runlevel += 2; /* skip waiting for TUNTAP IP address */
                traceEvent(TRACE_DEBUG, "skip auto IP address asignment");
            }
        }

        if(runlevel == 3) { /* REGISTER_SUPER to get auto ip address from a sn has been sent */
            if(!eee->sn_wait) { /* TUNTAP IP address received */
                runlevel++;
                traceEvent(TRACE_NORMAL, "received REGISTER_SUPER_ACK from supernode for IP address asignment");
                // it should be from curr_sn, but we can't determine definitely here, so no details to output
            } else if(last_action <= (now - BOOTSTRAP_TIMEOUT)) {
                // timeout, so try next supernode
                if(eee->curr_sn->hh.next)
                    eee->curr_sn = eee->curr_sn->hh.next;
                else
                    eee->curr_sn = eee->conf.supernodes;
                supernode_connect(eee);
                runlevel--;
                // skip waiting for answer to direcly go to send REGISTER_SUPER again
                seek_answer = 0;
                traceEvent(TRACE_DEBUG, "REGISTER_SUPER_ACK timeout");
            }
        }

        if(runlevel == 4) { /* configure the TUNTAP device, including routes */
            if(tuntap_open(&tuntap, eee->tuntap_priv_conf.tuntap_dev_name, eee->tuntap_priv_conf.ip_mode,
                           eee->tuntap_priv_conf.ip_addr, eee->tuntap_priv_conf.netmask,
                           eee->tuntap_priv_conf.device_mac, eee->tuntap_priv_conf.mtu) < 0) {
                keep_on_running=0;
                return 0;
            }
            memcpy(&eee->device, &tuntap, sizeof(tuntap));
            traceEvent(TRACE_NORMAL, "created local tap device IP: %s, Mask: %s, MAC: %s",
                                     eee->tuntap_priv_conf.ip_addr,
                                     eee->tuntap_priv_conf.netmask,
                                     macaddr_str(mac_buf, eee->device.mac_addr));
            // routes
            if(edge_init_routes(eee, eee->conf.routes, eee->conf.num_routes) < 0) {
                traceEvent(TRACE_ERROR, "routes setup failed");
                keep_on_running=0;
                return 0;
            }
            runlevel = 5;
            // no more answers required
            seek_answer = 0;
        }

        //设置user Data 用于arp代理
        /*memset(&private_status, 0, sizeof(private_status));
        private_status.gateway_ip = inet_addr("192.168.123.13");;//inet_addr(eee->tuntap_priv_conf.ip_addr);// gateway_ip.s_addr;
        private_status.conf = &conf;
        memcpy(private_status.tap_mac, eee->tuntap_priv_conf.device_mac, 6);
        //inet_aton(ip_addr, &tap_ip);
        private_status.tap_ipaddr = private_status.gateway_ip;//tap_ip.s_addr;*/



        // we usually wait for some answer, there however are exceptions when going back to a previous runlevel
        if(seek_answer) {
            FD_ZERO(&socket_mask);
            FD_SET(eee->sock, &socket_mask);
            wait_time.tv_sec = BOOTSTRAP_TIMEOUT;
            wait_time.tv_usec = 0;

            if(select(eee->sock + 1, &socket_mask, NULL, NULL, &wait_time) > 0) {
                if(FD_ISSET(eee->sock, &socket_mask)) {

                    fetch_and_eventually_process_data (eee, eee->sock,
                                                       pktbuf, &expected, &position,
                                                       now);
                }
            }
        }
        seek_answer = 1;

        resolve_check(eee->resolve_parameter, 0 /* no intermediate resolution requirement at this point */, now);
    }
    // allow a higher number of pings for first regular round of ping
    // to quicker get an inital 'supernode selection criterion overview'
    eee->conf.number_max_sn_pings = NUMBER_SN_PINGS_INITIAL;
    // shape supernode list; make current one the first on the list
    HASH_ITER(hh, eee->conf.supernodes, scan, scan_tmp) {
        if(scan == eee->curr_sn)
            sn_selection_criterion_good(&(scan->selection_criterion));
        else
            sn_selection_criterion_default(&(scan->selection_criterion));
    }
    sn_selection_sort(&(eee->conf.supernodes));
    // do not immediately ping again, allow some time
    eee->last_sweep = now - SWEEP_TIME + 2 * BOOTSTRAP_TIMEOUT;
    eee->sn_wait = 1;
    eee->last_register_req = 0;

    /*if((eee->tuntap_priv_conf.userid != 0) || (eee->tuntap_priv_conf.groupid != 0)) {
        traceEvent(TRACE_NORMAL, "dropping privileges to uid=%d, gid=%d",
                   (signed int)eee->tuntap_priv_conf.userid, (signed int)eee->tuntap_priv_conf.groupid);

        // Finished with the need for root privileges. Drop to unprivileged user.
        if((setgid(eee->tuntap_priv_conf.groupid) != 0)
           || (setuid(eee->tuntap_priv_conf.userid) != 0)) {
            traceEvent(TRACE_ERROR, "unable to drop privileges [%u/%s]", errno, strerror(errno));
            keep_on_running=0;
            return 0;
        }
    }*/

    //if((getuid() == 0) || (getgid() == 0))
    //    traceEvent(TRACE_WARNING, "running as root is discouraged, check out the -u/-g options");

    //设置回调函数
    n2n_edge_callbacks_t callbacks;
    memset(&callbacks, 0, sizeof(callbacks));
    callbacks.sn_registration_updated = on_sn_registration_updated;
    callbacks.packet_from_peer = on_packet_from_peer;
    callbacks.packet_from_tap = on_packet_from_tap;
    //callbacks.main_loop_period = on_main_loop_period;
    edge_set_callbacks(eee, &callbacks);

    {
        //初始化arp代理

        memcpy(lomm.hostmac ,eee->device.mac_addr,6);
        lomm.hostaddr = inet_addr(eee->tuntap_priv_conf.ip_addr);
        lomm.hostnetmask = inet_addr(eee->tuntap_priv_conf.netmask);
        rcn2n_init_arp(&lomm);
        edge_set_userdata(eee, &lomm);
    }

    keep_on_running = 1;
    eee->keep_running = &keep_on_running;
    traceEvent(TRACE_NORMAL, "edge started");
    rc = run_edge_loop(eee);
    print_edge_stats(eee);

    /* Cleanup */
    edge_term_conf(&eee->conf);
    tuntap_close(&eee->device);
    edge_term(eee);

    if ( tuncb ){
        free(tuncb);
    }

    if ( routeStr != NULL ) {
        freeRoute();
    }
    return(rc);
}

/* ************************************** */

static int utun_open(char *device_ip,char *device_mask,int mtu ){
#ifdef _BUILD_WITH_APPLE_MACOS_
    char utunname[32] ={0};
    socklen_t utunname_len = sizeof(utunname);
    struct ctl_info ctlInfo;
    memset(&ctlInfo,0,sizeof(ctlInfo));
    strncpy(ctlInfo.ctl_name,UTUN_CONTROL_NAME,sizeof(ctlInfo.ctl_name));
    int fd = -1;

    for ( int i = 0 ; i < 255;i++){
        struct sockaddr_ctl sc;
        fd = socket(PF_SYSTEM,SOCK_DGRAM,SYSPROTO_CONTROL);
        if (fd < 0 ){
            printf("open utun fail %d %s \n",errno, strerror(errno));
            return -1;
        }
        if ( ioctl(fd,CTLIOCGINFO,&ctlInfo) == -1){
            close(fd);
            fd = -1;
            continue;
        }
        memset(&sc,0,sizeof(sc));
        sc.sc_id = ctlInfo.ctl_id;
        sc.sc_len = sizeof(sc);
        sc.sc_family = AF_SYSTEM;
        sc.ss_sysaddr = AF_SYS_CONTROL;
        sc.sc_unit =  i+1;

        if (connect(fd,(struct  sockaddr*)&sc,sizeof(sc))<0){
            close(fd);
            fd = -1;
            continue;
        }

        fcntl(fd,F_SETFD,FD_CLOEXEC);
        fcntl(fd,F_SETFL,O_NONBLOCK);
        if ( fd >= 0 ){
            break;
        }
    }

    if ( fd > 0 ){
        getsockopt(fd,SYSPROTO_CONTROL,UTUN_OPT_IFNAME,utunname,&utunname_len);
    }

    char ifconfigcmd[512] = {0};
    snprintf(ifconfigcmd,512,"/sbin/ifconfig %s  %s %s netmask %s mtu %d up ",utunname,device_ip,device_ip,device_mask,mtu);
    system(ifconfigcmd);

    struct in_addr a;
    a.s_addr = inet_addr(device_ip)&inet_addr(device_mask);
    snprintf(ifconfigcmd,512,"/sbin/route add -net %s -netmask %s -iface %s",inet_ntoa(a),device_mask,utunname);
    system(ifconfigcmd);
    printf("run cmd %s \n",ifconfigcmd);

    for ( int i = 0 ; i < rcn2n_routesize ; i ++){
        char strip[32] = {0};
        char strmask[32] = {0};
        char strgateway[32] = {0};
        struct in_addr ip,mask,gateway;
        memset(&ip,0,sizeof(ip));
        memset(&mask,0,sizeof(mask));
        memset(&gateway,0,sizeof(gateway));
        ip.s_addr = rcn2nroute[i].ipaddr;
        mask.s_addr = rcn2nroute[i].ipmask;
        gateway.s_addr = rcn2nroute[i].gateway;
        strncpy(strip,inet_ntoa(ip),sizeof(strip));
        strncpy(strmask,inet_ntoa(mask),sizeof(strmask));
        strncpy(strgateway,inet_ntoa(gateway),sizeof(strgateway));
        snprintf(ifconfigcmd,512,"/sbin/route add -net %s -netmask %s %s",strip,strmask,strgateway);
        system(ifconfigcmd);
        printf("run cmd %s \n",ifconfigcmd);
    }
    return fd;
#endif
    return -1;
}

int tuntap_open (tuntap_dev *device /* ignored */,
                 char *dev,
                 const char *address_mode, /* static or dhcp */
                 char *device_ip,
                 char *device_mask,
                 const char * device_mac,
                 int mtu) {
    int fd = -1;
    if ( tuncb->tuntap_open ){
        fd = tuncb->tuntap_open(device_ip,device_mask,mtu);
    }else{
        fd = utun_open(device_ip,device_mask,mtu);
    }
    device->fd = fd;
    device->ip_addr = inet_addr(device_ip) ;
    device->device_mask = inet_addr(device_mask);
    memcpy(device->mac_addr,deviceMac,DEVICE_MAC_LEN);
    traceEvent(TRACE_NORMAL, "mac_addr %x:%x:%x:%x:%x:%x ",

               device->mac_addr[0],
                device->mac_addr[1],
                device->mac_addr[2],
                device->mac_addr[3],
                device->mac_addr[4],
                device->mac_addr[5]);
    return device->fd;
}

int tuntap_read (struct tuntap_dev *tuntap, unsigned char *buf, int len){
    if ( tuncb->tuntap_read ){
        return 14+tuncb->tuntap_read(tuntap->fd,buf+14,len-14);
    }
    return read(tuntap->fd,buf+10,len-10)+10;
}
int tuntap_write (struct tuntap_dev *tuntap, unsigned char *buf, int len) {
    if ( tuncb->tuntap_write ){
        return tuncb->tuntap_write(tuntap->fd,buf+14,len-14)+14;
    }
    buf[10] = 0;
    buf[11] = 0;
    buf[12] = 0;
    buf[13] = 2;
    int a = write(tuntap->fd , buf+10,len-10);
    return a;
}
void tuntap_close (struct tuntap_dev *tuntap){
    if ( tuncb->tuntap_close){
        tuncb->tuntap_close(tuntap->fd);
    }else {
        close(tuntap->fd);
    }
    tuntap->fd = -1;
    if ( rcn2nroute ){
        free(rcn2nroute);
        rcn2nroute = NULL;
        rcn2n_routesize = 0;
    }
}
void tuntap_get_address (struct tuntap_dev *tuntap) {}


static unsigned int maskToip(unsigned char m){
    unsigned int outmask = 0;
    for ( int i = 1 ; i <= m ; i++ ){
        outmask  |= ( 0x1 <<  (32-i));
    }
    char maskstr[32]={0};
    snprintf(maskstr,32,"%d.%d.%d.%d",
             (unsigned char)(outmask >> 24),
             (unsigned char)(outmask >> 16),
             (unsigned char)(outmask >> 8),
             (unsigned char)(outmask));
    return inet_addr(maskstr);
}

static void processRouteSt(const char* routestr,struct rcn2n_route* r){
    unsigned int ip1=0,ip2=0,ip3=0,ip4=0;
    unsigned int gw1=0,gw2=0,gw3=0,gw4=0;
    unsigned int mask=0;
    char tttt[128] = {0};
    strcpy(tttt,routestr);

    if ( sscanf(tttt,"%d.%d.%d.%d/%d/%d.%d.%d.%d",&ip1,&ip2,&ip3,&ip4,&mask,&gw1,&gw2,&gw3,&gw4) == 9 ) {
        char ip[32]={0};
        char gw[32]={0};
        snprintf(ip,32,"%d.%d.%d.%d",ip1,ip2,ip3,ip4);
        snprintf(gw,32,"%d.%d.%d.%d",gw1,gw2,gw3,gw4);
        r->ipaddr  = inet_addr(ip);
        r->gateway = inet_addr(gw);
        r->ipmask  = maskToip(mask);
    }
}

static void processRoute(const char* routestr){
    //计算路由个数

    for ( int i = 0 ; i < (int)strlen(routestr);i++) {
        if ( routestr[i] =='@'){
            rcn2n_routesize++;
        }
        if( i+1 == (int)strlen(routestr)){
            rcn2n_routesize++;
        }
    }

    rcn2nroute= (struct rcn2n_route*)malloc(rcn2n_routesize*(int)sizeof(struct rcn2n_route));

    int last = 0;
    int rcn2nroutesz = 0;
    for ( int i = 0 ; i < (int)strlen(routestr);i++){
        char routestrpoint[128]={0};
        if ( routestr[i] =='@'){
            strncpy(routestrpoint,routestr+last,i-last);
            processRouteSt(routestrpoint,&rcn2nroute[rcn2nroutesz++]);
            last = ++i;
        }
        if ( i+1 == (int)strlen(routestr)){
            i++;
            strncpy(routestrpoint,routestr+last,i-last);
            processRouteSt(routestrpoint,&rcn2nroute[rcn2nroutesz++]);
        }
    }
}
static void freeRoute(){
    if ( rcn2nroute != NULL){
        free(rcn2nroute);
        rcn2nroute = NULL;
        rcn2n_routesize = 0;
    }
}

