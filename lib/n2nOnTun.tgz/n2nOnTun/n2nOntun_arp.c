//
// Created by xiewei on 2023/5/26.
//

#include <netinet/in.h>
#include <string.h>
#include "n2n.h"
#include "n2nOntun_arp.h"



#define ARP_REQUEST 1
#define ARP_REPLY   2

static N2N_arp_ip arpip[RCN2N_ARP_SIZE]={0};
static LocalIpMaskMac loimm ={0};
static time_t lastRunArpTimer = 0;
void rcn2n_init_arp(LocalIpMaskMac* loipmaskmac){
    memset(arpip,0,sizeof(arpip));
    memset(&loimm,0,sizeof(loimm));
    if ( loipmaskmac != NULL){
        memcpy(&loimm,loipmaskmac,sizeof(loimm));
    }
}

int rcn2n_arpin_request(unsigned char* data,int datalen) {
    if(datalen < sizeof(RCN2NARP)) {
        return 0 ;
    }
    RCN2NARP* p = (RCN2NARP*)data;

    switch( htons(p->opcode)) {
        case (ARP_REQUEST):
            if ( p->d_ipaddr == loimm.hostaddr){
                //arp请求，回复arp应答
                p->opcode = htons(ARP_REPLY);

                memcpy(p->d_mac,p->s_mac,6);
                p->d_ipaddr = p->s_ipaddr;
                memcpy(p->s_mac , loimm.hostmac,6);
                p->s_ipaddr = loimm.hostaddr;

                memcpy(p->ethhdr.dest,p->ethhdr.src,6);
                memcpy(p->ethhdr.src,loimm.hostmac,6);
                return datalen;
            }
            break;
        case (ARP_REPLY):
            return rcn2n_arpin_reply(p);
    }
    return 0;
}

int rcn2n_arpin_reply(RCN2NARP* p) {
    for ( int i = 0 ; i < RCN2N_ARP_SIZE ; i++ ){
        if ( arpip[i].ipv4 == 0 ){
            arpip[i].ipv4 = p->s_ipaddr;
            memcpy(arpip[i].mac,p->s_mac,6);
            arpip[i].uptime = time(NULL);
            struct in_addr fip ;
            fip.s_addr = p->s_ipaddr;
            traceEvent(TRACE_WARNING, "recv new arp ip [%s] mac [%x:%x:%x:%x:%x:%x] ", inet_ntoa(fip),
                       p->s_mac[0], p->s_mac[1],p->s_mac[2],p->s_mac[3],p->s_mac[4],p->s_mac[5]);
            break;
        } else{
            continue;
        }
    }
    return 0;
}

void rcn2n_timer_arp(time_t now) {
    if (now > lastRunArpTimer + ARP_PERIOD_INTERVAL) {
        for (int i = 0; i < RCN2N_ARP_SIZE; i++) {
            if (arpip[i].ipv4 != 0 && arpip[i].uptime + ARP_PERIOD_INTERVAL < now) {
                arpip[i].ipv4 = 0;
                memset(arpip[i].mac, 0, 6);
                arpip[i].uptime = 0;
            }
        }
    }
}

void rcn2n_uninit_arp() {
    memset(arpip,0,sizeof(arpip));
    memset(&loimm,0,sizeof(loimm));
}

int  rcn2n_arpin_out(unsigned char* pb,int plen){
    if ( plen < sizeof(RCN2NARP)){
        return 0;
    }
    RCN2Nipv4* ipv4 = (RCN2Nipv4*)pb;
    unsigned int destip = ipv4->destipaddr;
    RCN2NARP* p = (RCN2NARP*)pb;
    memset(p->ethhdr.dest,0xff,6);
    memcpy(p->ethhdr.src,loimm.hostmac,6);
    p->ethhdr.type = htons(UIP_ETHTYPE_ARP);
    p->hwtype= htons(1);      //1
    p->protocol= htons(0x800);    //0x0800
    p->hwlen=6;       //6
    p->protolen=4;    //4
    p->opcode = htons(ARP_REQUEST);      //request 1 ,reply 2

    memcpy(p->s_mac,loimm.hostmac,6);
    memset(p->d_mac,0,6);
    p->s_ipaddr = loimm.hostaddr;
    p->d_ipaddr = destip;
    return sizeof(RCN2NARP);
}

unsigned char* findMacFormIpv4(unsigned int ipv4){
    for ( int i = 0 ; i < RCN2N_ARP_SIZE ;i++){
        if ( arpip[i].ipv4 == ipv4){
            return arpip->mac;
        }
    }
    struct in_addr a;
    a.s_addr = ipv4;
    return NULL;
}