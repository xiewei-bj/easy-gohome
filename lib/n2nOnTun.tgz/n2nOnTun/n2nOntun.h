
#ifndef __RC_N2N___
#define __RC_N2N___
#ifdef __cplusplus
extern "C" {
#endif
#define DEVICE_MAC_LEN 6

typedef struct {
    int (*tuntap_open)(char *device_ip,        //tun上的ip
                    char *device_mask,         //tun上的掩码
                    int mtu);                  //tun的MTU
    int (*tuntap_read)(int fd, unsigned char *buf, int len);
    int (*tuntap_write)(int fd, unsigned char *buf, int len);
    void (*tuntap_close)(int fd);
}TunCb;

//主要方法调用，阻塞，返回了就是n2n关闭
//const char* routeStr 格式：
//0.0.0.0/24/0.0.0.0@ipaddr/mask/gw
extern int _n2nmain(char *community_name, char *pk, char *publidIpport,const char* routeStr,TunCb* cb,unsigned char mac[DEVICE_MAC_LEN]);
extern void stopedge();
extern int edgeStatus();
#ifdef __cplusplus
}
#endif
#endif