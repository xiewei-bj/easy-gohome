#include "n2n.h"
#ifndef _RCN2N_EDGE_H_
#define _RCN2N_EDGE_H_
struct rcn2n_route{
    unsigned int ipaddr;    //ip地址
    unsigned int ipmask;    //掩码
    unsigned int gateway;   //网关
    unsigned int res;       //占位
};

//各个平台，要实现各自的功能
extern int tuntap_open (tuntap_dev *device,     //device  要设置fd,ipaddr,mask, mac, mtu
                 char *dev,                 //忽略吧，没什么用
                 const char *address_mode,  /* static or dhcp 也没什么用*/
                 char *device_ip,           //tun上的ip
                 char *device_mask,         //tun上的掩码
                 const char * device_mac,   //这个一般为空的，你也要负责生成一个随机mac
                 int mtu);                  //tun的MTU
extern int tuntap_read (struct tuntap_dev *tuntap, unsigned char *buf, int len);   //如果是tun模式，buf+14,len-14 为了给二层头预留出空间
extern int tuntap_write (struct tuntap_dev *tuntap, unsigned char *buf, int len);  //如果是tun模式，buf+14,len-14 为了跳过二层头
                                                                                   //macos 用网络字节序0x00000002 代替二层头
extern void tuntap_close (struct tuntap_dev *tuntap);
extern void tuntap_get_address (struct tuntap_dev *tuntap);
#endif