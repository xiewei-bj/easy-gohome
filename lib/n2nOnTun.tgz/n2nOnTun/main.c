#include <stdio.h>
#include <arpa/inet.h>
#include <string.h>
#include "edge.h"
#include "n2nOntun.h"

static void printargs(){
    printf("-c community_name             :  -c network      \n");
    printf("-k auth_key                   :  -k abcdefg                      \n");
    printf("-l public node ip and port    :  -l 123.123.123.123:12345\n");
    printf("-r add net/host route for n2n :  -r 192.168.1.0/24/192.168.2.2 \n");
    exit(0);
}


static unsigned int maskToip(unsigned char m){
    unsigned int outmask = 0;
    for ( int i = 1 ; i <= m ; i++ ){
        outmask  |= ( 0x1 <<  (32-i));
    }
    char maskstr[32]={0};
    snprintf(maskstr,32,"%d.%d.%d.%d",
             (unsigned char)(outmask >> 24),
             (unsigned char)(outmask >> 16),
             (unsigned char)(outmask >> 8),
             (unsigned char)(outmask));
    return inet_addr(maskstr);
}

void _n2nExLog(char* str){
    printf("%s\n",str);
}

static unsigned int getTimeStamp(){
    struct timeval tv;
    gettimeofday(&tv, NULL);
    return (unsigned int)( tv.tv_sec * 1000 + tv.tv_usec / 1000 );
}

void vpnServiceProtect(int fd){}

int main(int argc, char* argv[]){

    if ( argc == 1 ){
        printargs();
    }

    char* routeString = NULL;
    char* community_name = NULL;
    char* auth_key = NULL;
    char* public_node = NULL;
    int routesize = 0;
    for ( int i = 1 ; i < argc ; i++){
        char* ar = argv[i];
        if ( ar[0] == '-' ){
            switch (ar[1]) {
                case 'c':
                case 'C':
                    community_name = argv[++i];
                    break;
                case 'k':
                case 'K':
                    auth_key = argv[++i];
                    break;
                case 'l':
                case 'L':
                    public_node = argv[++i];
                    break;
                case 'r':
                case 'R':
                    routesize++;
                    i++;
                    break;
                default:
                    printargs();
            }
        }
    }

    if ( routesize > 0 ){
        int routelen = 64*routesize;
        routeString = malloc(routelen);
        memset(routeString,0,routelen);
        for ( int i = 1 ; i < argc ; i++){
            if (strcmp("-r",argv[i]) == 0 || strcmp("-R",argv[i]) == 0 ){
                strcat(routeString,argv[++i]);
                strcat(routeString,"@");
            }else{
                ++i;
            }
        }
    }

    if ( routeString != NULL && strlen(routeString) > 0 ){
        routeString[strlen(routeString)-1]=0;
        printf("route : %s\n",routeString);
    }

    if(community_name == NULL||auth_key == NULL||public_node == NULL){
        printargs();
    }
    unsigned int st = getTimeStamp();
    unsigned char mac[DEVICE_MAC_LEN];
    memcpy(mac+1,&st,4);
    mac[0]=0xcc;
    mac[5]=0x3f;
    return _n2nmain(community_name,auth_key,public_node,routeString,NULL,mac);
}