//
// Created by xiewei on 2023/5/26.
//

#ifndef RCN2N_RCN2N_ARP_H
#define RCN2N_RCN2N_ARP_H

#define RCN2N_ARP_SIZE 8


typedef struct {
    unsigned int  ipv4;
    unsigned char mac[6] ;
    long          uptime;   //更新时间，秒
}N2N_arp_ip;

#pragma pack(1)
typedef struct {
    unsigned char  dest[6]; //目的mac
    unsigned char  src[6];  //源mac
    unsigned short type;    //包类型 0x0806 arp ，0x0800 ipv4
} arp_ethII_hdr;

typedef struct  {
    arp_ethII_hdr  ethhdr;      //以太网头
    unsigned short hwtype;      //1
    unsigned short protocol;    //0x0800
    unsigned char  hwlen;       //6
    unsigned char  protolen;    //4
    unsigned short opcode;      //request 1 ,reply 2
    unsigned char  s_mac[6];    //sender mac
    unsigned int   s_ipaddr;    //sender ip
    unsigned char  d_mac[6];    //target mac
    unsigned int   d_ipaddr;    //target ip
} RCN2NARP;

typedef struct {
    arp_ethII_hdr  ethhdr;      //以太网头
    unsigned char  vhl;
    unsigned char  tos;
    unsigned char  len[2];
    unsigned char  ipid[2];
    unsigned char  ipoffset[2];
    unsigned char  ttl;
    unsigned char  proto;
    unsigned short ipchksum;
    unsigned int   srcipaddr;       //源ip
    unsigned int   destipaddr;      //目的ip
}RCN2Nipv4;
#pragma pack()

typedef struct {
    unsigned int hostaddr    ;
    unsigned int hostnetmask ;
    unsigned char hostmac[6] ;
    unsigned char zero[2] ;
}LocalIpMaskMac;

#define UIP_ETHTYPE_ARP 0x0806
#define UIP_ETHTYPE_IP  0x0800

#define ARP_PERIOD_INTERVAL     10 /* sec */

extern void rcn2n_init_arp(LocalIpMaskMac* loipmaskmac);
extern int  rcn2n_arpin_request(unsigned char* data,int datalen);  //arp请求进入 返回值>0，需要将data发出 ,==0 不需要处理
extern int  rcn2n_arpin_reply(RCN2NARP* p);    //arp应答进入
extern int  rcn2n_arpin_out(unsigned char* p,int plen);
extern void rcn2n_timer_arp(time_t now);       //定时处理，arp老化
extern unsigned char* findMacFormIpv4(unsigned int ipv4);
extern void rcn2n_uninit_arp();


#endif //RCN2N_RCN2N_ARP_H
